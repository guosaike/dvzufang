import { createRouter, createWebHistory } from "vue-router";
import NProgress from "nprogress"; //进度条
import "nprogress/nprogress.css";

NProgress.configure({
  showSpinner: false, //通过将其设置为 false 来关闭加载微调器。
});

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      redirect: "/home/index",
      hidden: true,
    },
    {
      path: "/login",
      name: "login",
      meta: { title: "登陆" },
      component: () => import("@/views/admin/login.vue"),
      hidden: true,
    },
    {
      path: "/media",
      name: "media",
      meta: { title: "媒体" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "list",
          name: "media-list",
          meta: { title: "媒体资源列表" },
          component: () => import("@/views/admin/media-list.vue"),
        },
      ],
    },
    {
      path: "/user",
      name: "user",
      meta: { title: "用户" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "list",
          name: "user-list",
          meta: { title: "用户列表" },
          component: () => import("@/views/admin/user-list.vue"),
        },
      ],
    },
    // 卖家管理
    {
      path: "/cs",
      name: "cs",
      meta: { title: "卖家管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "csgl",
          name: "csgl",
          meta: { title: "卖家管理" },
          component: () => import("@/views/admin/csgl.vue"),
        },
      ],
    },

    // 买家管理
    {
      path: "/gm",
      name: "gm",
      meta: { title: "买家管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "gmgl",
          name: "gmgl",
          meta: { title: "买家管理" },
          component: () => import("@/views/admin/gmgl.vue"),
        },
      ],
    },

    // 分类管理
    {
      path: "/fl",
      name: "fl",
      meta: { title: "分类管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "flgl",
          name: "flgl",
          meta: { title: "分类管理" },
          component: () => import("@/views/admin/flgl.vue"),
        },
      ],
    },

    // 地区管理
    {
      path: "/dq",
      name: "dq",
      meta: { title: "地区管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "dqgl",
          name: "dqgl",
          meta: { title: "地区管理" },
          component: () => import("@/views/admin/dqgl.vue"),
        },
      ],
    },

    // 商品管理
    {
      path: "/sp",
      name: "sp",
      meta: { title: "商品管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "spgl",
          name: "spgl",
          meta: { title: "商品管理" },
          component: () => import("@/views/admin/spgl.vue"),
        },
      ],
    },

    // 地址管理
    {
      path: "/htdz",
      name: "htdz",
      meta: { title: "地址管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "dzgl",
          name: "dzgl",
          meta: { title: "地址管理" },
          component: () => import("@/views/admin/dzgl.vue"),
        },
      ],
    },

    // 订单管理
    {
      path: "/dd",
      name: "dd",
      meta: { title: "开课管理" },
      component: () => import("@/views/admin/main.vue"),
      children: [
        {
          path: "ddgl",
          name: "ddgl",
          meta: { title: "开课列表" },
          component: () => import("@/views/admin/ddgl.vue"),
        },
      ],
    },

    // 用户前台
    {
      path: '/home',
      name: 'mainqiantai',
      component: () => import('@/views/Mainqiantai.vue'),
      children: [
        {
          path: 'index',
          name: 'index',
          component: () => import("@/views/Index.vue"),
        },
        {
          path: 'detail',
          name: 'detail',
          component: () => import("@/views/Detail.vue"),
        },
        {
          path: 'confirm',
          name: 'confirm',
          component: () => import("@/views/Confirm.vue"),
        },
        {
          path: 'pay',
          name: 'pay',
          component: () => import("@/views/Pay.vue"),
        },
        {
          path: 'usercenter',
          name: 'usercenter',
          redirect: '/home/usercenter/order',
          component: () => import("@/views/User.vue"),
          children: [
            {
              path: 'order',
              name: 'order',
              component: () => import("@/views/Order.vue"),
            },
            {
              path: 'dz',
              name: 'dz',
              component: () => import("@/views/Mydz.vue"),
            },
          ]
        },
        
      ]
    },
  ],
});

import defaultSettings from "@/settings";

//路由全局前置钩子
router.beforeEach((to, from, next) => {
  NProgress.start();
  document.title = `${to.meta.title || "B站程序员科科"} - ${defaultSettings.title}`;
  let token = localStorage.getItem("token");
  if (token) {
    next();
  } else {
    next();
  }
});

// //路由全局后置钩子
router.afterEach(() => {
  NProgress.done();
});

export default router;
