<template>
    <!-- <el-button type="primary" @click="visible = true">申请</el-button> -->
    <el-card shadow="never" style="margin-top: 10px;">
        <!-- 表格区域 -->
        <el-table :data="tableData" stripe>
            <el-table-column prop="name" label="名称" />
            <el-table-column prop="price" label="价格" />
            <el-table-column prop="dizhi" label="地址" />
            <el-table-column prop="maijia.username" label="房东名称" />
            <el-table-column prop="fenlei.mingcheng" label="分类名称" />
            <el-table-column prop="diqu.mingcheng" label="地区名称" />
            
            <!-- <el-table-column prop="cttime" label="创建时间" width="260" />
            <el-table-column prop="mdtime" label="更新时间" width="260" /> -->

            <!-- <el-table-column label="操作" width="180" fixed="right">
                    <template #default="scope">
                        <el-dropdown @command="handleCommand" trigger="click">
                            <div v-if="isAdmin != 3">
                            <el-button type="primary" @click="er(scope.row)" >审批</el-button>
                            </div>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item divided command="1">同意</el-dropdown-item>
                                    <el-dropdown-item divided command="2">拒绝</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                    </template>
                </el-table-column> -->


        </el-table>
        <!-- 分页 -->
        <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            layout="sizes, total, prev, pager, next" :total="totalNum" :currentPage="search.pageNum"
            :pageSize="search.pageSize">
        </el-pagination>


          <!-- 新增或编辑的抽屉 -->
        <sDrawer v-model="visible" :title="form.id ? '编辑选课' : '添加学院'" size="35%" :close-on-click-modal="false">

            <el-form :model="form" label-width="80px" ref="ruleFormRef">
            <el-form-item label="分数:">
                <el-input v-model="form.score" />
            </el-form-item>
            </el-form>

            <template #footer>
            <el-button @click="visible = false">取消</el-button>
            <el-button type="primary" @click="saveData()">确定</el-button>
            </template>
        </sDrawer>

    </el-card>
</template>
  
<script>
import sDrawer from "@/components/s-drawer/s-drawer.vue"
export default {
    components: {
        sDrawer,
    },
    watch: {
        visible(value) {
            if (!value) {
                this.form = {}
            }
        }
    },
    data() {
        return {
            form: {},
            visible: false,
            tableData: [],
            totalNum: 0,
            search: {
                pageNum: 1,
                pageSize: 10,
                shenhezt: 1,
                isAdmin: "",
                nickname: "",
            },
            search1: {
                pageNum: 1,
                pageSize: 20,
                shenhezt: 1
            },
            statusMap: {
                0: '待审核',
                1: '已通过',
                2: '未通过', // 根据您的实际状态码定义对应的中文描述
            },
        };
    },
    created() {
        this.search.token = localStorage.getItem("token");
        this.search1.token = localStorage.getItem("token");
        this.search.nickname = localStorage.getItem("nickname");
        this.search.isAdmin = localStorage.getItem("isAdmin");
        this.getList();
        this.nickname = localStorage.getItem("nickname");
        this.isAdmin = localStorage.getItem("isAdmin");
    },
    methods: {
        async getList() {
            this.$api.gethtjqysh(
                this.search
                ).then(res=>{
                    if (res.data.code === 200){
                    this.tableData = res.data.data;
                    this.totalNum = res.data.zs
                    }
                })
        },

        // 每页条数改变时触发 选择一页显示多少行
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
            this.search.pageSize = val;
            this.getList();
        },
        // 当前页改变时触发 跳转其他页
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`);
            this.search.pageNum = val;
            this.getList();
        },
        resetSearch() {
            let search = {
                pageNum: this.search.pageNum,
                pageSize: this.search.pageSize,
            };
            this.search = search;
            this.getList();
        },
        editItem(row) {
            this.form = this.$deepClone(row)
            this.visible = true
        },
        er(row) {
            this.form.id = row.id
            this.form.student_id = row.student.id
            this.form.open_id = row.open.id
            this.form.shenpi_ren = this.nickname
        }

    },
};
</script>
  
<style scoped>
.el-pagination {
    margin-top: 10px;
}

.el-dropdown-link {
    cursor: pointer;
    color: #409EFF;
}

.el-icon-arrow-down {
    font-size: 12px;
}

.el-row {
    margin-bottom: 20px;
}

.el-row:last-child {
    margin-bottom: 0px;
}
</style>