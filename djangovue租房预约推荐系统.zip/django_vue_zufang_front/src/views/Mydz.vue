<template>
  <div>
    我的地址
    <br>
    <br>
    <el-button @click="editItem()">增加</el-button>
    <br>
    <el-table :data="dzdata" border stripe>
      <el-table-column prop="username" label="姓名"></el-table-column>
      <el-table-column prop="shouji" label="手机"></el-table-column>
      <el-table-column prop="addr" label="地址"></el-table-column>
      <!-- <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column> -->
    <el-table-column label="操作">
      <template #default="scope">
        <el-button @click="editItem(scope.row)">编辑</el-button>
        <el-button @click="deleteItem(scope.row)">删除</el-button>
      </template>
    </el-table-column>
    </el-table>

    <el-dialog :title="'编辑地址'" v-model="dialogVisible" @close="closeDialog">
  <el-form :model="form" label-width="80px">
    <el-form-item label="姓名">
      <el-input v-model="form.username" />
    </el-form-item>
    <el-form-item label="手机">
      <el-input v-model="form.shouji" />
    </el-form-item>
    <el-form-item label="地址">
      <el-input v-model="form.addr" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="saveItem">Save</el-button>
    </el-form-item>
  </el-form>
</el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      items: [],
      loading: true,
      dialogVisible: false,
      dzdata: [],
      form: {
        id: null,
        name: '',
        description: '',
      },
    };
  },

  created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.isAdmin = localStorage.getItem("isAdmin");
    this.mydz();
  },

  methods: {
    mydz(){
      this.$api.mydz(
            {
                pageNum:1,
                pageSize:8,
                userInfoid:this.userInfoid,
            }
        ).then(res=>{
            if (res.data.code === 200){
              console.log(res.data.data)
                this.dzdata = res.data.data
            }
        })
    },

    editItem(item) {
      console.log(item)
      this.dialogVisible = true;
      this.form.username = item.username;
      this.form.shouji = item.shouji;
      this.form.addr = item.addr;
      this.form.id = item.id;
    },

    deleteItem(item) {
      this.$confirm('是否删除', '删除地址', {
                  confirmButtonText: '删除',
                  cancelButtonText: '取消',
                  type: 'warning'
              }).then(() => {
                  this.$api.deletedizhi(
                      {
                        id: item.id,
                      }
                  ).then(res=>{
                      if (res.data.code === 200){
                        this.dialogVisible = false;
                        window.location.reload();
                        console.log('修改8888888888888888888888888')
                      }
                  })
                }
      )
    },

    saveItem() {
      if (this.form.id) {
        this.$api.updatedizhi(
            {
              id: this.form.id,
              shui_id: this.userInfoid,
              username: this.form.username,
              shouji: this.form.shouji,
              addr: this.form.addr
            }
        ).then(res=>{
            if (res.data.code === 200){
              this.dialogVisible = false;
              window.location.reload();
              console.log('修改8888888888888888888888888')
            }
        })
      } else {
        this.$api.createdizhi(
            {
              shui_id: this.userInfoid,
              username: this.form.username,
              shouji: this.form.shouji,
              addr: this.form.addr
            }
        ).then(res=>{
            if (res.data.code === 200){
              this.dialogVisible = false;
              window.location.reload();
              console.log('修改8888888888888888888888888')
            }
        })
      }
    },

    closeDialog() {
      this.dialogVisible = false;
      this.form.id = null;
      this.form.name = '';
      this.form.description = '';
    },
  },
};
</script>